package com.citi.fund.model;

import lombok.Data;

/**
 * create by Cunzhen Zheng
 */
@Data
public class Fund {
    private int id;
    private String fundId;
    private String name;
    private String employeeId;

}
