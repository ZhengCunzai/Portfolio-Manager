package com.citi.fund.model;

import lombok.Data;


/**
 * create by Cunzhen Zheng
 */
@Data
public class Security {
    private int id;
    private String securityId;
    private String symbol;

}
