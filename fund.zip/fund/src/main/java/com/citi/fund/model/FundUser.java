package com.citi.fund.model;

import lombok.Data;


/**
 * create by Cunzhen Zheng
 */
@Data
public class FundUser {
    private int id;
    private String fundId;
    private String email;
    private String employeeId;

}
